'use client';

import {
  AlertTriangle,
  CircuitBoard,
  Gauge,
  Building2,
  Loader2,
  Radar,
  Layers,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Card } from '@/components/ui/card';
import type { KpiCardData, RiskLevel } from '@/lib/types';
import { riskTextClass } from '@/lib/risk';
import { cn } from '@/lib/utils';

interface KpiCardsProps {
  cards?: KpiCardData[];
  loading?: boolean;
  projected?: boolean;
}

const ICONS: Record<string, LucideIcon> = {
  'active-incidents': AlertTriangle,
  'critical-nodes': CircuitBoard,
  'cascade-risk': Gauge,
  'affected-services': Building2,
  'blast-radius': Radar,
  'cascade-depth': Layers,
};

export function KpiCards({ cards, loading = false, projected = false }: KpiCardsProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Card
            key={i}
            className="flex h-[100px] items-center justify-center border-border bg-card/40"
          >
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          </Card>
        ))}
      </div>
    );
  }

  const display = cards ?? [];
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {display.map((card) => {
        const Icon = ICONS[card.id] ?? AlertTriangle;
        return <KpiCard key={card.id} card={card} Icon={Icon} projected={projected} />;
      })}
    </div>
  );
}

function KpiCard({
  card,
  Icon,
  projected = false,
}: {
  card: KpiCardData;
  Icon: LucideIcon;
  projected?: boolean;
}) {
  const risk = card.risk ?? 'low';
  return (
    <Card className="relative overflow-hidden border-border bg-card/70 p-4">
      <div className="flex items-start justify-between">
        <span className="text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground">
          {card.label}
        </span>
        <div className="flex items-center gap-1">
          {projected && (
            <span className="rounded bg-primary/15 px-1 py-0.5 text-[8px] font-semibold uppercase tracking-wider text-primary">
              Proj
            </span>
          )}
          <Icon className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="font-mono text-3xl font-semibold tabular-nums text-foreground">
          {card.value}
        </span>
        <RiskDot risk={risk} />
      </div>
      <p className={cn('mt-1.5 text-xs', riskTextClass(risk))}>{card.indicator}</p>
    </Card>
  );
}

function RiskDot({ risk }: { risk: RiskLevel }) {
  return <span className={`h-2 w-2 rounded-full risk-bg-${risk}`} aria-hidden />;
}
