'use client';

import { useState, useEffect } from 'react';
import { Activity, Zap, RotateCcw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  INCIDENT_TYPE_OPTIONS,
  SECTOR_OPTIONS,
  SEVERITY_OPTIONS,
  SECTOR_LABELS,
  type IncidentType,
  type Sector,
  type Severity,
  type GraphNode,
} from '@/lib/types';

interface IncidentFormProps {
  nodes: GraphNode[];
  loading?: boolean;
  onAnalyze?: (config: {
    incidentType: IncidentType;
    sector: Sector;
    assetId: string;
    assetLabel: string;
    severity: Severity;
  }) => void;
  onDemo?: () => void;
  analyzing?: boolean;
}

export function IncidentForm({
  nodes,
  loading = false,
  onAnalyze,
  onDemo,
  analyzing = false,
}: IncidentFormProps) {
  const [incidentType, setIncidentType] = useState<IncidentType>('power_outage');
  const [sector, setSector] = useState<Sector>('power');
  const [assetId, setAssetId] = useState<string>('sldc');
  const [severity, setSeverity] = useState<Severity>('high');

  const sectorNodes = nodes.filter((n) => n.sector === sector);

  useEffect(() => {
    if (sectorNodes.length > 0 && !sectorNodes.some((n) => n.id === assetId)) {
      setAssetId(sectorNodes[0].id);
    }
  }, [sector, sectorNodes, assetId]);

  const selectedNode = nodes.find((n) => n.id === assetId);

  function handleAnalyze() {
    onAnalyze?.({
      incidentType,
      sector,
      assetId,
      assetLabel: selectedNode?.label ?? assetId,
      severity,
    });
  }

  return (
    <aside className="flex h-full flex-col bg-card">
      <div className="border-b border-border px-4 py-4">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-primary" />
          <h2 className="text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
            Incident Control
          </h2>
        </div>
        <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
          Define the initiating event and analyze its downstream impact.
        </p>
      </div>

      <div className="flex-1 space-y-5 overflow-y-auto px-4 py-5">
        <Field label="Incident Type" htmlFor="incident-type">
          <Select
            value={incidentType}
            onValueChange={(v) => setIncidentType(v as IncidentType)}
            disabled={loading}
          >
            <SelectTrigger id="incident-type" className="bg-background/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {INCIDENT_TYPE_OPTIONS.map((t) => (
                <SelectItem key={t.value} value={t.value}>
                  {t.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        <Field label="Sector" htmlFor="sector">
          <Select
            value={sector}
            onValueChange={(v) => setSector(v as Sector)}
            disabled={loading}
          >
            <SelectTrigger id="sector" className="bg-background/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SECTOR_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        <Field label="Affected Asset" htmlFor="asset">
          <Select
            value={assetId}
            onValueChange={setAssetId}
            disabled={loading || sectorNodes.length === 0}
          >
            <SelectTrigger id="asset" className="bg-background/50">
              <SelectValue placeholder={loading ? 'Loading assets…' : 'Select asset'} />
            </SelectTrigger>
            <SelectContent>
              {sectorNodes.map((n) => (
                <SelectItem key={n.id} value={n.id}>
                  {n.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedNode && (
            <p className="mt-1.5 text-[10px] text-muted-foreground">
              Criticality {selectedNode.criticality}/10 · ID:{' '}
              <span className="font-mono">{selectedNode.id}</span>
            </p>
          )}
        </Field>

        <Field label="Severity" htmlFor="severity">
          <Select
            value={severity}
            onValueChange={(v) => setSeverity(v as Severity)}
            disabled={loading}
          >
            <SelectTrigger id="severity" className="bg-background/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SEVERITY_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  <span className="flex items-center gap-2">
                    <span
                      className={`h-2 w-2 rounded-full risk-bg-${s.value}`}
                    />
                    {s.label}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      </div>

      <div className="space-y-2.5 border-t border-border px-4 py-4">
        <Button
          onClick={handleAnalyze}
          disabled={loading || analyzing || sectorNodes.length === 0}
          className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
        >
          {analyzing ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Zap className="h-4 w-4" />
          )}
          {analyzing ? 'Analyzing…' : 'Analyze Cascade'}
        </Button>
        <Button
          onClick={onDemo}
          disabled={loading || analyzing}
          variant="outline"
          className="w-full gap-2 border-border bg-background/50 text-foreground hover:bg-secondary"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          Load Demo Incident
        </Button>
      </div>
    </aside>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <label
        htmlFor={htmlFor}
        className="text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground"
      >
        {label}
      </label>
      {children}
    </div>
  );
}

export { SECTOR_LABELS };
