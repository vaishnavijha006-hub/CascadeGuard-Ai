'use client';

import ReactFlow, {
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  type Node,
  type Edge,
  type NodeTypes,
} from 'reactflow';
import 'reactflow/dist/style.css';
import type {
  GraphNode,
  GraphEdge,
  AnalysisNode,
  RiskLevel,
  Sector,
} from '@/lib/types';
import { SECTOR_LABELS, EDGE_TYPE_LABELS } from '@/lib/types';
import { riskHex, RISK_LABELS } from '@/lib/risk';
import { Loader2 } from 'lucide-react';

interface CascadeMapProps {
  graphNodes?: GraphNode[];
  graphEdges?: GraphEdge[];
  analysis?: AnalysisNode[];
  loading?: boolean;
  simulated?: boolean;
  horizon?: number;
  selectedNodeId?: string | null;
  onNodeClick?: (id: string) => void;
}

interface CascadeNodeData {
  label: string;
  sector: Sector;
  risk: RiskLevel;
  impactTime: number;
  criticality: number;
  visible: boolean;
  selected: boolean;
}

function CascadeNode({ data }: { data: CascadeNodeData }) {
  const color = riskHex(data.risk);
  return (
    <div
      className="min-w-[180px] rounded-md border bg-card/90 px-3 py-2.5 shadow-lg backdrop-blur-sm transition-opacity"
      style={{
        borderColor: color,
        opacity: data.visible ? 1 : 0.35,
        boxShadow: data.selected ? `0 0 0 2px ${color}` : undefined,
      }}
    >
      <div className="flex items-center gap-2">
        <span
          className="h-2.5 w-2.5 shrink-0 rounded-full"
          style={{ backgroundColor: color }}
        />
        <span className="truncate text-xs font-medium text-foreground">
          {data.label}
        </span>
      </div>
      <div className="mt-1.5 flex items-center justify-between pl-[18px]">
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
          {SECTOR_LABELS[data.sector]}
        </span>
        <span className="font-mono text-[10px] tabular-nums" style={{ color }}>
          T+{data.impactTime}
        </span>
      </div>
    </div>
  );
}

const nodeTypes: NodeTypes = { cascade: CascadeNode };

const EDGE_COLORS: Record<string, string> = {
  power: 'hsl(25 88% 55%)',
  comms: 'hsl(187 85% 48%)',
  data: 'hsl(43 90% 55%)',
  control: 'hsl(142 64% 45%)',
};

const EDGE_STYLES: Record<string, string> = {
  power: 'solid',
  comms: 'dashed',
  data: 'dotted',
  control: 'solid',
};

export function CascadeMap({
  graphNodes = [],
  graphEdges = [],
  analysis = [],
  loading = false,
  simulated = false,
  horizon,
  selectedNodeId = null,
  onNodeClick,
}: CascadeMapProps) {
  const analysisMap = new Map<string, AnalysisNode>();
  analysis.forEach((a) => analysisMap.set(a.id, a));

  const nodes: Node[] = graphNodes.map((n) => {
    const an = analysisMap.get(n.id);
    const risk: RiskLevel = an?.level ?? 'low';
    const impactTime = an?.impact_time_min ?? 0;
    const visible = horizon === undefined || impactTime <= horizon;
    return {
      id: n.id,
      type: 'cascade',
      position: { x: n.x, y: n.y },
      data: {
        label: n.label,
        sector: n.sector,
        risk,
        impactTime,
        criticality: n.criticality,
        visible,
        selected: n.id === selectedNodeId,
      } satisfies CascadeNodeData,
    };
  });

  const edges: Edge[] = graphEdges.map((e) => ({
    id: e.id,
    source: e.source,
    target: e.target,
    type: 'smoothstep',
    animated: true,
    label: EDGE_TYPE_LABELS[e.type],
    labelStyle: { fill: 'hsl(220 14% 62%)', fontSize: 9 },
    labelBgStyle: { fill: 'hsl(222 40% 9%)' },
    style: {
      stroke: EDGE_COLORS[e.type] ?? 'hsl(222 22% 30%)',
      strokeWidth: 1.5,
      opacity: 0.6,
      strokeDasharray: EDGE_STYLES[e.type] === 'dashed' ? '6 3' : EDGE_STYLES[e.type] === 'dotted' ? '2 3' : undefined,
    },
  }));

  return (
    <div className="relative h-[520px] w-full overflow-hidden rounded-md border border-border bg-background">
      {loading ? (
        <div className="flex h-full flex-col items-center justify-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Building dependency graph…
          </span>
        </div>
      ) : (
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          fitView
          fitViewOptions={{ padding: 0.18 }}
          proOptions={{ hideAttribution: true }}
          nodesDraggable
          zoomOnScroll
          panOnScroll
          onNodeClick={(_, node) => onNodeClick?.(node.id)}
        >
          <Background
            variant={BackgroundVariant.Dots}
            gap={22}
            size={1.5}
            color="hsl(222 22% 20%)"
          />
          <Controls
            showInteractive={false}
            className="!rounded-md !border !border-border !bg-card"
          />
          <MiniMap
            pannable
            zoomable
            nodeColor={(n) => {
              const data = n.data as CascadeNodeData;
              return riskHex(data.risk);
            }}
            maskColor="hsl(222 47% 6% / 0.7)"
          />
        </ReactFlow>
      )}
      <div className="pointer-events-none absolute left-3 top-3 z-10 flex items-center gap-2 rounded border border-border bg-card/80 px-2.5 py-1.5 backdrop-blur-sm">
        <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-foreground">
          Cascade Map
        </span>
        <span className="text-[10px] text-muted-foreground">
          {graphNodes.length} nodes · {graphEdges.length} dependencies
        </span>
        {simulated && (
          <span className="rounded bg-primary/15 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-primary">
            Simulated
          </span>
        )}
      </div>
      {/* Risk legend */}
      <div className="pointer-events-none absolute right-3 top-3 z-10 flex flex-col gap-1 rounded border border-border bg-card/80 px-2.5 py-2 backdrop-blur-sm">
        <span className="mb-0.5 text-[8px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          Risk
        </span>
        {(['critical', 'high', 'moderate', 'low'] as RiskLevel[]).map((r) => (
          <div key={r} className="flex items-center gap-1.5">
            <span
              className="h-2 w-2 rounded-full"
              style={{ backgroundColor: riskHex(r) }}
            />
            <span className="text-[9px] uppercase tracking-wider text-muted-foreground">
              {RISK_LABELS[r]}
            </span>
          </div>
        ))}
      </div>
      {/* Edge type legend */}
      <div className="pointer-events-none absolute bottom-3 right-3 z-10 flex flex-col gap-1 rounded border border-border bg-card/80 px-2.5 py-2 backdrop-blur-sm">
        {Object.entries(EDGE_COLORS).map(([type, color]) => (
          <div key={type} className="flex items-center gap-1.5">
            <span
              className="h-0 w-4 border-t-2"
              style={{
                borderColor: color,
                borderStyle:
                  EDGE_STYLES[type] === 'dashed'
                    ? 'dashed'
                    : EDGE_STYLES[type] === 'dotted'
                      ? 'dotted'
                      : 'solid',
              }}
            />
            <span className="text-[9px] uppercase tracking-wider text-muted-foreground">
              {EDGE_TYPE_LABELS[type as keyof typeof EDGE_TYPE_LABELS]}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
