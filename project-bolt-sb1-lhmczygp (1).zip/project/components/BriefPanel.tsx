'use client';

import { FileText, AlertCircle, TrendingUp, ShieldAlert, Scale } from 'lucide-react';
import type { AnalyzeResponse } from '@/lib/types';

interface BriefPanelProps {
  brief?: AnalyzeResponse['brief'];
  loading?: boolean;
}

export function BriefPanel({ brief, loading = false }: BriefPanelProps) {
  if (loading) {
    return (
      <section className="rounded-md border border-border bg-card/60 p-4">
        <div className="mb-3 flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary" />
          <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
            Operational Brief
          </h3>
        </div>
        <div className="space-y-2">
          <div className="h-3 w-full animate-pulse rounded bg-muted/50" />
          <div className="h-3 w-5/6 animate-pulse rounded bg-muted/40" />
          <div className="h-3 w-4/6 animate-pulse rounded bg-muted/30" />
        </div>
      </section>
    );
  }

  if (!brief) {
    return (
      <section className="rounded-md border border-border bg-card/60 p-4">
        <div className="mb-3 flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary" />
          <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
            Operational Brief
          </h3>
        </div>
        <p className="text-xs leading-relaxed text-muted-foreground">
          No analysis loaded. Define an incident and run Analyze Cascade, or
          load the demo incident to generate an operational summary.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-md border border-border bg-card/60 p-4">
      <div className="mb-3 flex items-center gap-2">
        <FileText className="h-4 w-4 text-primary" />
        <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
          Operational Brief
        </h3>
      </div>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        <BriefItem
          icon={AlertCircle}
          label="Situation"
          text={brief.situation}
        />
        <BriefItem
          icon={TrendingUp}
          label="Projection"
          text={brief.projection}
        />
        <BriefItem
          icon={ShieldAlert}
          label="Recommendation"
          text={brief.recommendation}
        />
        <BriefItem
          icon={Scale}
          label="Compliance"
          text={brief.compliance}
        />
      </div>
    </section>
  );
}

function BriefItem({
  icon: Icon,
  label,
  text,
}: {
  icon: typeof AlertCircle;
  label: string;
  text: string;
}) {
  return (
    <div className="rounded-md border border-border bg-background/40 p-3">
      <div className="mb-1.5 flex items-center gap-1.5">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          {label}
        </span>
      </div>
      <p className="text-xs leading-relaxed text-foreground/90">{text}</p>
    </div>
  );
}
