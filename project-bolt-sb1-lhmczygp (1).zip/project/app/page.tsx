'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ChevronDown, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { Header } from '@/components/Header';
import { IncidentForm } from '@/components/Sidebar/IncidentForm';
import { KpiCards } from '@/components/KpiCards';
import { CascadeMap } from '@/components/CascadeMap';
import { Timeline } from '@/components/Timeline';
import { NodeDetails } from '@/components/NodeDetails';
import { BlastRadius } from '@/components/BlastRadius';
import { ResponsePanel } from '@/components/ResponsePanel';
import { SectorChart, toSectorImpactPoints } from '@/components/SectorChart';
import { BriefPanel } from '@/components/BriefPanel';
import { SimulationComparison } from '@/components/SimulationComparison';
import { getGraph, analyze, simulate } from '@/lib/api';
import { riskFromScore } from '@/lib/risk';
import type {
  GraphResponse,
  GraphNode,
  AnalyzeResponse,
  SimulateResponse,
  KpiCardData,
  Action,
  IncidentType,
  Sector,
  Severity,
} from '@/lib/types';
import { cn } from '@/lib/utils';

export default function Page() {
  const [graph, setGraph] = useState<GraphResponse | null>(null);
  const [graphLoading, setGraphLoading] = useState(true);

  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzeError, setAnalyzeError] = useState(false);

  const [simulation, setSimulation] = useState<SimulateResponse | null>(null);
  const [simulating, setSimulating] = useState(false);
  const [simulateError, setSimulateError] = useState(false);

  const [selectedActions, setSelectedActions] = useState<Action[]>([]);

  const [incidentLabel, setIncidentLabel] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [horizon, setHorizon] = useState(0);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);

  const lastSimulateRequest = useRef<{
    incident_type: string;
    asset_id: string;
    severity: string;
    actions: string[];
  } | null>(null);

  const playTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      setGraphLoading(true);
      const g = await getGraph();
      if (active) {
        setGraph(g);
        setGraphLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const displayNodes = useMemo(
    () => simulation?.nodes ?? analysis?.nodes ?? [],
    [simulation, analysis]
  );

  const markers = useMemo(() => {
    const times = displayNodes.map((a) => a.impact_time_min).sort((a, b) => a - b);
    const unique = Array.from(new Set(times));
    return unique.length > 0 ? unique : [0];
  }, [displayNodes]);

  // Play demo: advance through timeline markers
  useEffect(() => {
    if (!playing) return;
    const currentIndex = markers.indexOf(horizon);
    if (currentIndex === -1 || currentIndex >= markers.length - 1) {
      setPlaying(false);
      return;
    }
    playTimer.current = setTimeout(() => {
      setHorizon(markers[currentIndex + 1]);
    }, 1200);
    return () => {
      if (playTimer.current) clearTimeout(playTimer.current);
    };
  }, [playing, horizon, markers]);

  const runAnalyze = useCallback(
    async (params: {
      incidentType: IncidentType;
      sector: Sector;
      assetId: string;
      assetLabel: string;
      severity: Severity;
    }) => {
      setAnalyzing(true);
      setAnalyzeError(false);
      setIncidentLabel(params.assetLabel);
      setSimulation(null);
      setSimulateError(false);
      setSelectedActions([]);
      setSelectedNodeId(null);
      setPlaying(false);
      setHorizon(0);
      try {
        const res = await analyze({
          incident_type: params.incidentType,
          sector: params.sector,
          asset_id: params.assetId,
          severity: params.severity,
        });
        setAnalysis(res);
        setHorizon(res.summary.first_impact_min);
      } catch {
        setAnalyzeError(true);
      } finally {
        setAnalyzing(false);
      }
    },
    []
  );

  const handleDemo = useCallback(() => {
    void runAnalyze({
      incidentType: 'ransomware' as IncidentType,
      sector: 'power' as Sector,
      assetId: 'sldc',
      assetLabel: 'State Load Dispatch Center',
      severity: 'high' as Severity,
    });
  }, [runAnalyze]);

  const handleReset = useCallback(() => {
    setSimulation(null);
    setSimulateError(false);
    setSelectedActions([]);
    setSelectedNodeId(null);
    setPlaying(false);
    if (analysis) {
      setHorizon(analysis.summary.first_impact_min);
    }
  }, [analysis]);

  const runSimulate = useCallback(
    async (ids: string[]) => {
      if (!analysis) return;
      const request = {
        incident_type: analysis.incident.type,
        asset_id: analysis.incident.source_id,
        severity: analysis.incident.severity,
        actions: ids,
      };
      lastSimulateRequest.current = request;
      setSimulating(true);
      setSimulateError(false);
      try {
        const res = await simulate({
          incident_type: request.incident_type,
          sector: 'power',
          asset_id: request.asset_id,
          severity: request.severity,
          actions: ids,
        });
        setSimulation(res);
      } catch {
        setSimulateError(true);
      } finally {
        setSimulating(false);
      }
    },
    [analysis]
  );

  const handleSimulate = useCallback(
    (ids: string[]) => {
      void runSimulate(ids);
    },
    [runSimulate]
  );

  const handleRetry = useCallback(() => {
    if (lastSimulateRequest.current) {
      void runSimulate(lastSimulateRequest.current.actions);
    }
  }, [runSimulate]);

  const handleSelectionChange = useCallback(
    (ids: string[]) => {
      const actionMap = new Map(analysis?.actions.map((a) => [a.id, a]) ?? []);
      setSelectedActions(
        ids
          .map((id) => actionMap.get(id))
          .filter((a): a is Action => a !== undefined)
      );
    },
    [analysis]
  );

  const handleNodeClick = useCallback((id: string) => {
    setSelectedNodeId(id);
  }, []);

  const handleSelectNodeFromDetails = useCallback((id: string) => {
    setSelectedNodeId(id);
  }, []);

  const selectedNode: GraphNode | null = useMemo(() => {
    if (!selectedNodeId || !graph) return null;
    return graph.nodes.find((n) => n.id === selectedNodeId) ?? null;
  }, [selectedNodeId, graph]);

  const kpiCards: KpiCardData[] = useMemo(() => {
    if (!analysis) return [];
    const riskScore = simulation
      ? simulation.after.risk_score
      : analysis.summary.risk_score;
    const criticalNodes = simulation
      ? simulation.after.high_or_critical
      : analysis.summary.critical_nodes;
    return [
      {
        id: 'active-incidents',
        label: 'Active Incidents',
        value: 1,
        indicator: `${analysis.incident.type} on ${analysis.incident.source_id}`,
        risk: 'high',
      },
      {
        id: 'critical-nodes',
        label: 'High/Critical Nodes',
        value: criticalNodes,
        indicator: simulation ? 'projected after intervention' : 'at immediate risk',
        risk: riskFromScore(criticalNodes / 12),
      },
      {
        id: 'cascade-risk',
        label: 'Cascade Risk',
        value: riskScore,
        indicator: simulation
          ? `${simulation.delta.risk_pct > 0 ? '+' : ''}${simulation.delta.risk_pct}% projected`
          : 'composite index',
        risk: riskFromScore(riskScore / 100),
      },
      {
        id: 'affected-services',
        label: 'Affected Services',
        value: analysis.summary.affected_nodes,
        indicator: `depth ${analysis.summary.cascade_depth} layers`,
        risk: 'moderate',
      },
    ];
  }, [analysis, simulation]);

  const sectorImpactData = useMemo(
    () => (analysis ? toSectorImpactPoints(analysis.sector_impact) : []),
    [analysis]
  );

  const showLoading = analyzing && !analysis;

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background text-foreground">
      <Header
        simulationActive={!!simulation}
        actionCount={selectedActions.length}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar — desktop */}
        <div className="hidden w-[300px] shrink-0 border-r border-border md:block lg:w-[320px]">
          <IncidentForm
            nodes={graph?.nodes ?? []}
            loading={graphLoading}
            onAnalyze={runAnalyze}
            onDemo={handleDemo}
            analyzing={analyzing}
          />
        </div>

        {/* Sidebar — mobile collapsible */}
        <div className="md:hidden">
          <button
            type="button"
            onClick={() => setSidebarOpen((v) => !v)}
            className="flex w-full items-center justify-between border-b border-border bg-card/60 px-4 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-foreground"
          >
            <span className="flex items-center gap-2">
              {sidebarOpen ? (
                <PanelLeftClose className="h-4 w-4 text-primary" />
              ) : (
                <PanelLeftOpen className="h-4 w-4 text-primary" />
              )}
              Incident Control
            </span>
            <ChevronDown
              className={cn(
                'h-4 w-4 text-muted-foreground transition-transform',
                sidebarOpen && 'rotate-180'
              )}
            />
          </button>
          {sidebarOpen && (
            <div className="border-b border-border">
              <IncidentForm
                nodes={graph?.nodes ?? []}
                loading={graphLoading}
                onAnalyze={runAnalyze}
                onDemo={handleDemo}
                analyzing={analyzing}
              />
            </div>
          )}
        </div>

        {/* Main dashboard */}
        <main className="flex flex-1 flex-col gap-3 overflow-y-auto p-3 md:p-4">
          {/* KPI row */}
          <KpiCards
            cards={kpiCards}
            loading={showLoading}
            projected={!!simulation}
          />

          {/* Cascade map */}
          <CascadeMap
            graphNodes={graph?.nodes ?? []}
            graphEdges={graph?.edges ?? []}
            analysis={displayNodes}
            loading={graphLoading}
            simulated={!!simulation}
            horizon={horizon}
            selectedNodeId={selectedNodeId}
            onNodeClick={handleNodeClick}
          />

          {/* Timeline */}
          <Timeline
            analysis={displayNodes}
            loading={showLoading}
            horizon={horizon}
            onHorizonChange={(h) => {
              setHorizon(h);
              setPlaying(false);
            }}
            playing={playing}
            onPlayToggle={() => {
              if (markers.length <= 1) return;
              if (playing) {
                setPlaying(false);
              } else if (horizon >= markers[markers.length - 1]) {
                setHorizon(markers[0]);
                setPlaying(true);
              } else {
                setPlaying(true);
              }
            }}
            onReset={handleReset}
          />

          {/* Node details + Blast radius */}
          {selectedNode ? (
            <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
              <NodeDetails
                node={selectedNode}
                analysis={displayNodes}
                graphNodes={graph?.nodes ?? []}
                graphEdges={graph?.edges ?? []}
                activeEdges={analysis?.edges_active}
                onClose={() => setSelectedNodeId(null)}
                onSelectNode={handleSelectNodeFromDetails}
              />
              <BlastRadius
                analysis={analysis}
                graphNodes={graph?.nodes ?? []}
                loading={showLoading}
              />
            </div>
          ) : (
            <BlastRadius
              analysis={analysis}
              graphNodes={graph?.nodes ?? []}
              loading={showLoading}
            />
          )}

          {/* Operational brief */}
          <BriefPanel brief={analysis?.brief} loading={showLoading} />

          {/* Simulation comparison (BEFORE/AFTER) */}
          <SimulationComparison
            simulation={simulation}
            simulating={simulating}
            error={simulateError}
            selectedActions={selectedActions}
            onRetry={handleRetry}
          />

          {/* Bottom panels: response + sector impact */}
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <ResponsePanel
              actions={analysis?.actions ?? []}
              loading={showLoading}
              simulating={simulating}
              onSimulate={handleSimulate}
              onSelectionChange={handleSelectionChange}
            />
            <SectorChart data={sectorImpactData} loading={showLoading} />
          </div>

          {/* Status footer */}
          <div className="flex items-center justify-between rounded-md border border-border bg-card/40 px-3 py-2 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            <span>
              {incidentLabel
                ? `Simulated incident: ${incidentLabel}`
                : 'No incident loaded — define or load a demo scenario'}
            </span>
            <span className="font-mono">
              {analysis
                ? `Risk ${simulation?.after.risk_score ?? analysis.summary.risk_score} · ${analysis.summary.affected_nodes} nodes · v0.5`
                : 'v0.5'}
            </span>
          </div>
        </main>
      </div>
    </div>
  );
}
