import type {
  GraphResponse,
  AnalyzeRequest,
  AnalyzeResponse,
  SimulateRequest,
  SimulateResponse,
} from './types';
import graphMock from '@/mock/graph.json';
import analyzeMock from '@/mock/analyze.json';
import simulateMock from '@/mock/simulate.json';

const API_TIMEOUT_MS = 3000;

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), ms);
  return promise.finally(() => clearTimeout(timeout)) as Promise<T>;
}

async function fetchJson<T>(
  url: string,
  options?: RequestInit
): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers ?? {}),
      },
    });
    clearTimeout(timeout);
    if (!res.ok) {
      throw new Error(`API ${res.status}: ${res.statusText}`);
    }
    return (await res.json()) as T;
  } catch (err) {
    clearTimeout(timeout);
    throw err;
  }
}

export async function getGraph(): Promise<GraphResponse> {
  try {
    return await withTimeout(
      fetchJson<GraphResponse>('/api/graph'),
      API_TIMEOUT_MS
    );
  } catch {
    return graphMock as GraphResponse;
  }
}

export async function analyze(request: AnalyzeRequest): Promise<AnalyzeResponse> {
  try {
    return await withTimeout(
      fetchJson<AnalyzeResponse>('/api/analyze', {
        method: 'POST',
        body: JSON.stringify(request),
      }),
      API_TIMEOUT_MS
    );
  } catch {
    return analyzeMock as AnalyzeResponse;
  }
}

export async function simulate(
  request: SimulateRequest
): Promise<SimulateResponse> {
  try {
    return await withTimeout(
      fetchJson<SimulateResponse>('/api/simulate', {
        method: 'POST',
        body: JSON.stringify(request),
      }),
      API_TIMEOUT_MS
    );
  } catch {
    return simulateMock as SimulateResponse;
  }
}
