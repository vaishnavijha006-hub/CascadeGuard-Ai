/* ---------- Core domain types (API contract) ---------- */

export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export type Sector =
  | 'power'
  | 'telecom'
  | 'health'
  | 'water'
  | 'transport'
  | 'finance'
  | 'data'
  | 'public';

export type EdgeType = 'power' | 'comms' | 'data' | 'control';

export type IncidentType =
  | 'ransomware'
  | 'power_outage'
  | 'telecom_failure'
  | 'flood'
  | 'supply_disruption';

export type Severity = 'low' | 'moderate' | 'high' | 'critical';

/* ---------- Graph ---------- */

export interface GraphNode {
  id: string;
  label: string;
  sector: Sector;
  criticality: number;
  x: number;
  y: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: EdgeType;
  weight: number;
  delay_min: number;
}

export interface GraphResponse {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

/* ---------- Analysis ---------- */

export interface AnalysisNode {
  id: string;
  risk: number;
  level: RiskLevel;
  impact_time_min: number;
  depth: number;
  why: string;
}

export interface Action {
  id: string;
  priority: 'P1' | 'P2' | 'P3' | 'P4';
  title: string;
  description: string;
  est_risk_reduction_pct: number;
}

export interface AnalyzeResponse {
  incident: {
    type: string;
    severity: string;
    source_id: string;
  };
  summary: {
    risk_score: number;
    cascade_depth: number;
    affected_nodes: number;
    critical_nodes: number;
    first_impact_min: number;
  };
  nodes: AnalysisNode[];
  edges_active: string[];
  sector_impact: {
    sector: Sector;
    avg_risk: number;
  }[];
  blast_radius: {
    id: string;
    score: number;
  }[];
  actions: Action[];
  brief: {
    situation: string;
    projection: string;
    recommendation: string;
    compliance: string;
  };
}

/* ---------- Requests ---------- */

export interface AnalyzeRequest {
  incident_type: string;
  sector: Sector;
  asset_id: string;
  severity: string;
}

export interface SimulateRequest extends AnalyzeRequest {
  actions: string[];
}

export interface SimulateResponse {
  before: {
    risk_score: number;
    high_or_critical: number;
    hospital_impact_min: number;
  };
  after: {
    risk_score: number;
    high_or_critical: number;
    hospital_impact_min: number;
  };
  delta: {
    risk_pct: number;
    delay_min: number;
  };
  nodes: AnalysisNode[];
}

/* ---------- UI helper types (derived, not API contract) ---------- */

export interface KpiCardData {
  id: string;
  label: string;
  value: number | string;
  indicator: string;
  risk?: RiskLevel;
}

export interface CascadeNodeData {
  id: string;
  label: string;
  sector: Sector;
  risk: RiskLevel;
  impactTime: number;
  position: { x: number; y: number };
}

export interface CascadeEdgeData {
  id: string;
  source: string;
  target: string;
  type: EdgeType;
}

export interface ResponseAction {
  id: string;
  priority: 'P1' | 'P2' | 'P3' | 'P4';
  title: string;
  description: string;
  est_risk_reduction_pct: number;
  applied: boolean;
}

export interface SectorImpactPoint {
  sector: string;
  impact: number;
}

/* ---------- Option lists for forms ---------- */

export const INCIDENT_TYPE_OPTIONS: { value: IncidentType; label: string }[] = [
  { value: 'ransomware', label: 'Ransomware' },
  { value: 'power_outage', label: 'Power Outage' },
  { value: 'telecom_failure', label: 'Telecom Failure' },
  { value: 'flood', label: 'Flood' },
  { value: 'supply_disruption', label: 'Supply Disruption' },
];

export const SECTOR_OPTIONS: { value: Sector; label: string }[] = [
  { value: 'power', label: 'Power' },
  { value: 'telecom', label: 'Telecom' },
  { value: 'health', label: 'Health' },
  { value: 'water', label: 'Water' },
  { value: 'transport', label: 'Transport' },
  { value: 'finance', label: 'Finance' },
  { value: 'data', label: 'Data' },
  { value: 'public', label: 'Public' },
];

export const SEVERITY_OPTIONS: { value: Severity; label: string }[] = [
  { value: 'low', label: 'Low' },
  { value: 'moderate', label: 'Moderate' },
  { value: 'high', label: 'High' },
  { value: 'critical', label: 'Critical' },
];

export const SECTOR_LABELS: Record<Sector, string> = {
  power: 'Power',
  telecom: 'Telecom',
  health: 'Health',
  water: 'Water',
  transport: 'Transport',
  finance: 'Finance',
  data: 'Data',
  public: 'Public',
};

export const EDGE_TYPE_LABELS: Record<EdgeType, string> = {
  power: 'Power',
  comms: 'Comms',
  data: 'Data',
  control: 'Control',
};
